﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations;

namespace XBCAD_MVC_WebApplication.Models
{
    public class Staff
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string UserType { get; set; } = "Staff"; // Default user type
    }

}
