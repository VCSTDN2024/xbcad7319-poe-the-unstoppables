﻿// Define the Message class
public class Message
{
    public string Content { get; set; }
    public string UserType { get; set; }
    public DateTime Timestamp { get; set; }
}