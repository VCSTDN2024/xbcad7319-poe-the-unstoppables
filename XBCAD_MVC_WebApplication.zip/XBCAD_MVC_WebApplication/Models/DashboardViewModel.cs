﻿public class DashboardViewModel
{
    public Dictionary<string, int> DepartmentQueryCounts { get; set; }
    public Dictionary<string, int> QueryTypeCounts { get; set; }
    public Dictionary<string, TimeSpan> AverageResponseTimes { get; set; }
    public double ResolutionRate { get; set; }
    public List<QueryDetails> Queries { get; set; }
}
