﻿public class UserDetails
{
    public string Email { get; set; }
    public string Department { get; set; }
}