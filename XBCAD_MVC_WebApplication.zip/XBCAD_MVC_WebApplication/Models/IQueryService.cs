﻿public interface IQueryService
{
    Task<List<QueryDetails>> GetAllQueries();
}
