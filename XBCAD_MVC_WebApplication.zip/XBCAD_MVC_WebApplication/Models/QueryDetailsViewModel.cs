﻿using FirebaseAdmin.Messaging;

public class QueryDetailsViewModel
{
    public string QueryId { get; set; }
    public string QueryTitle { get; set; }
    public string QueryDescription { get; set; }
    public string Status { get; set; }
    public string StudentEmail { get; set; }
    public List<Message> Messages { get; set; } = new List<Message>();
    public bool HasSubmittedFeedback { get; set; }
}
