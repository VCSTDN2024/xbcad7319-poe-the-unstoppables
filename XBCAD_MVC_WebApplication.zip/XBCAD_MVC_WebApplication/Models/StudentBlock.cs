﻿
    public class StudentBlock
    {
    public string Email { get; set; }
    public string Department { get; set; }  // Assuming you have departments for filtering studentss
}
