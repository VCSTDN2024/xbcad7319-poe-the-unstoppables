﻿using System.ComponentModel.DataAnnotations;

namespace XBCAD_MVC_WebApplication.Models
{
    public class Student
    {
        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [MinLength(10, ErrorMessage = "Student ID must be at least 10 characters.")]
        [Display(Name = "Student ID")]
        public string StudentId { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        public string Course { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [Display(Name = "User Type")]
        public string UserType { get; set; } = "Student";
    }
}
