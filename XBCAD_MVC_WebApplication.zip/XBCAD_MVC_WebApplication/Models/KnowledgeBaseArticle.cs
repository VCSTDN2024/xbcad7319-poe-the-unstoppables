﻿namespace XBCAD_MVC_WebApplication.Models
{
    public class KnowledgeBaseArticle
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
