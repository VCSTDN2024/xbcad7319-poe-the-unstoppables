﻿public class ReportQueryViewModel
{
    public string QueryID { get; set; }
    public string Title { get; set; }
    public string QueryType { get; set; }
    public string Department { get; set; }
    public string SubmissionDate { get; set; }
    public string ResolvedDate { get; set; }
    public string TimeDifference { get; set; }  // Added field for time difference
}
