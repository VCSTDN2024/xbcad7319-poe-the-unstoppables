﻿public class QueryDetails
{
    public string Title { get; set; }
    public string QueryType { get; set; }
    public string Department { get; set; }
    public DateTime SubmissionDate { get; set; }
    public DateTime? ResolvedDate { get; set; }
}
