﻿public class QueryViewModel
{
    public string QueryID { get; set; }
    public string QueryType { get; set; }
    public string Title { get; set; }

    public string Description { get; set; }
    public string Status { get; set; }
    public string SubmissionDate { get; set; }
    public string DocumentPath { get; set; }
    public string ResolvedDate { get; set; }
    public string StudentEmail { get; set; }  // For lecturer view, to see which student submitted the query
}
