﻿using Google.Cloud.Firestore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using XBCAD_MVC_WebApplication;

public class QueryService : IQueryService
{
    private readonly FirestoreDb _firestoreDb;

    public QueryService()
    {
        _firestoreDb = FirebaseService.GetFirestoreDb();
    }

    public async Task<List<QueryDetails>> GetAllQueries()
    {
        var queries = new List<QueryDetails>();
        var querySnapshot = await _firestoreDb.Collection("queries").GetSnapshotAsync();

        foreach (var document in querySnapshot.Documents)
        {
            var query = document.ConvertTo<QueryDetails>();
            queries.Add(query);
        }

        return queries;
    }
}
