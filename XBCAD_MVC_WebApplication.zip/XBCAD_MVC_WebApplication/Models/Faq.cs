﻿namespace XBCAD_MVC_WebApplication.Models
{
    public class Faq
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }
}
