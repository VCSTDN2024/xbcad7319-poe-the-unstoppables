﻿using Firebase.Database;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Firestore;
using System;
using System.IO;

namespace XBCAD_MVC_WebApplication
{
    public class FirebaseService
    {
        private static FirestoreDb _firestoreDb;
        private static FirebaseClient _firebaseClient;

        public static void InitializeFirebase()
        {
            var pathToServiceAccountKey = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "firebase", "xbcad-app-952a3-firebase-adminsdk-2zap7-16500204fb.json");

            if (!File.Exists(pathToServiceAccountKey))
            {
                throw new FileNotFoundException("Firebase service account key not found", pathToServiceAccountKey);
            }

            // Explicitly set the credentials using the service account file
            FirebaseApp.Create(new AppOptions()
            {
                Credential = GoogleCredential.FromFile(pathToServiceAccountKey)
            });

            // Initialize FirebaseClient for Realtime Database
            _firebaseClient = new FirebaseClient("https://xbcad-app-952a3-default-rtdb.firebaseio.com/");
        }

        // Get Firestore instance
        public static FirestoreDb GetFirestoreDb()
        {
            if (_firestoreDb == null)
            {
                _firestoreDb = FirestoreDb.Create("xbcad-app-952a3");
            }
            return _firestoreDb;
        }

        // Get FirebaseClient instance for Realtime Database
        public static FirebaseClient GetFirebaseClient()
        {
            if (_firebaseClient == null)
            {
                throw new InvalidOperationException("FirebaseClient is not initialized. Call InitializeFirebase() first.");
            }
            return _firebaseClient;
        }
    }
}
