﻿using Firebase.Database;
using Firebase.Database.Query;
using Microsoft.AspNetCore.Mvc;
using XBCAD_MVC_WebApplication.Models;

namespace XBCAD_MVC_WebApplication.Controllers
{
    public class DashboardController : Controller
    {
        private readonly FirebaseClient _firebaseClient;

        bool documentAdded = false;

        public DashboardController()
        {
            // Initialize FirebaseClient
            _firebaseClient = FirebaseService.GetFirebaseClient(); // Assume you have this method for initializing Firebase
        }

        // GET: Display the Query Submission Form
        public IActionResult SubmitQuery()
        {
            return View();
        }

        public IActionResult Communication()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SubmitQuery(QuerySubmissionModel model)
        {
            if (ModelState.IsValid)
            {
                // Get the current student's email (stored in session after login)
                var studentEmail = HttpContext.Session.GetString("UserEmail");
                if (string.IsNullOrEmpty(studentEmail))
                {
                    ViewBag.ErrorMessage = "Please log in to submit a query.";
                    return RedirectToAction("Login", "Student");
                }

                // Generate unique query ID
                var queryId = Guid.NewGuid().ToString();

                // Initialize documentPath
                string documentPath = "null";

                // Check if a document is uploaded
                if (Request.Form.Files.Count > 0)
                {
                    var file = Request.Form.Files[0];
                    documentPath = await UploadDocument(file); // Upload and get the path
                }

                // Fetch all users from Firebase (without querying by email directly)
                var users = await _firebaseClient
                    .Child("users")
                    .OnceAsync<dynamic>(); // Get all users as a list

                // Find the student by email in the fetched data
                var student = users.FirstOrDefault(u => u.Object.Email == studentEmail);
                if (student == null)
                {
                    ViewBag.ErrorMessage = "Student not found.";
                    return RedirectToAction("Login", "Student");
                }

                // Get the department from the student's Firebase data
                var studentDepartment = student.Object.Department ?? "Unknown"; // Default to "Unknown" if no department is found

                // Prepare query data for Firebase
                var query = new
                {
                    QueryID = queryId,
                    StudentEmail = studentEmail,
                    Department = studentDepartment,  // Assign department
                    QueryType = model.QueryType,
                    Title = model.Title,
                    Description = model.Description,
                    DocumentPath = documentPath,
                    SubmissionDate = DateTime.UtcNow.AddHours(2).ToString("yyyy-MM-dd HH:mm:ss"),
                    Status = "Pending",
                    Response = (string)null,
                    ResolvedDate = (string)null
                };

                try
                {
                    // Store query in Firebase
                    await _firebaseClient
                        .Child("queries")
                        .Child(queryId)
                        .PutAsync(query);

                    Console.WriteLine("Query successfully uploaded.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error uploading query to Firebase: {ex.Message}");
                    throw;
                }

                return RedirectToAction("Dashboard", "Student");
            }

            return View(model);
        }


        /*
        // POST: Handle the Query Submission
        [HttpPost]
        public async Task<IActionResult> SubmitQuery(QuerySubmissionModel model)
        {
            if (ModelState.IsValid)
            {
                // Get the current student's email (stored in session after login)
                var studentEmail = HttpContext.Session.GetString("UserEmail");
                if (string.IsNullOrEmpty(studentEmail))
                {
                    ViewBag.ErrorMessage = "Please log in to submit a query.";
                    return RedirectToAction("Login", "Student");
                }

                // Generate unique query ID
                var queryId = Guid.NewGuid().ToString();

                // Initialize documentPath
                string documentPath = "null";

                // Check if a document is uploaded
                if (Request.Form.Files.Count > 0)
                {
                    var file = Request.Form.Files[0];
                    documentPath = await UploadDocument(file); // Upload and get the path
                }

                // Prepare query data for Firebase
                var query = new
                {
                    QueryID = queryId,
                    StudentEmail = studentEmail,
                    QueryType = model.QueryType,
                    Title = model.Title,
                    Description = model.Description,
                    DocumentPath = documentPath,
                    SubmissionDate = DateTime.UtcNow.AddHours(2).ToString("yyyy-MM-dd HH:mm:ss"),
                    Status = "Pending",
                    Response = (string)null,
                    ResolvedDate = (string)null
                };

                try
                {
                    // Store query in Firebase
                    await _firebaseClient
                        .Child("queries")
                        .Child(queryId)
                        .PutAsync(query);

                    Console.WriteLine("Query successfully uploaded.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error uploading query to Firebase: {ex.Message}");
                    throw;
                }

                return RedirectToAction("Dashboard", "Student");
            }

            return View(model);
        }
        */
        // UploadDocument helper function
        private async Task<string> UploadDocument(IFormFile document)
        {
            if (document != null && document.Length > 0)
            {
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads/documents");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var filePath = Path.Combine(uploadsFolder, document.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await document.CopyToAsync(stream);
                }

                return $"/uploads/documents/{document.FileName}";
            }

            return "null";
        }




        // GET: Display Status Tracking (for students to view their queries)
        public async Task<IActionResult> StatusTracking()
        {
            var studentEmail = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(studentEmail))
            {
                return RedirectToAction("Login", "Student");
            }

            // Query Firebase for all queries submitted by this student
            var queries = await _firebaseClient
                .Child("queries")
                .OnceAsync<dynamic>();

            var studentQueries = queries
                .Where(q => q.Object.StudentEmail == studentEmail)
                .Select(q => new QueryViewModel
                {
                    QueryID = q.Key,
                    QueryType = q.Object.QueryType,
                    Title = q.Object.Title,
                    Description = q.Object.Description,
                    Status = q.Object.Status,
                    SubmissionDate = q.Object.SubmissionDate,
                    DocumentPath = q.Object.DocumentPath,
                    ResolvedDate = q.Object.ResolvedDate
                })
                .ToList();

            return View(studentQueries);
        }

        // Method to get all queries for a lecturer (if needed)
        public async Task<IActionResult> LecturerDashboard()
        {
            var queries = await _firebaseClient
                .Child("queries")
                .OnceAsync<dynamic>();

            var allQueries = queries
                .Select(q => new QueryViewModel
                {
                    QueryID = q.Key,
                    QueryType = q.Object.QueryType,
                    Title = q.Object.Title,
                    Status = q.Object.Status,
                    SubmissionDate = q.Object.SubmissionDate,
                    StudentEmail = q.Object.StudentEmail, // Include the student email or ID
                    DocumentPath = q.Object.DocumentPath,
                    ResolvedDate = q.Object.ResolvedDate
                })
                .ToList();

            return View(allQueries);
        }

        [HttpPost]
        public async Task<IActionResult> SendMessage(string messageContent)
        {
            // Ensure user is logged in
            var userEmail = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(userEmail))
            {
                ViewBag.ErrorMessage = "Please log in to send a message.";
                return RedirectToAction("Login", "Student");
            }

            try
            {
                // Fetch all users to find the sender's document in Firebase
                var users = await _firebaseClient
                    .Child("users")
                    .OnceAsync<dynamic>();

                var sender = users.FirstOrDefault(u => u.Object.Email == userEmail);
                if (sender == null)
                {
                    ViewBag.ErrorMessage = "User not found.";
                    return RedirectToAction("Login", "Student");
                }

                // Get the user's Firebase key
                var userKey = sender.Key;
                Console.WriteLine($"User Key: {userKey}"); // Debugging log

                // Prepare message data
                var message = new
                {
                    Content = messageContent,
                    UserType = "Student", // Adjust dynamically if needed
                    Timestamp = DateTime.UtcNow.AddHours(2).ToString("yyyy-MM-dd HH:mm:ss")
                };

                // Add the message to the communication sub-collection
                var result = await _firebaseClient
                    .Child($"users/{userKey}/communication")
                    .PostAsync(message);

                Console.WriteLine($"Message posted to Firebase with key: {result.Key}"); // Debugging log

                // Redirect back to messages page after successful post
                return RedirectToAction("Messages", "Dashboard");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending message: {ex.Message}"); // Debugging log
                ViewBag.ErrorMessage = "Failed to send message.";
                return View(); // Show error if post fails
            }
        }



        /*
        [HttpPost]
        public async Task<IActionResult> SendMessage(string messageContent)
        {
            // Ensure user is logged in
            var userEmail = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(userEmail))
            {
                ViewBag.ErrorMessage = "Please log in to send a message.";
                return RedirectToAction("Login", "Student");
            }

            try
            {
                // Fetch all users to find the sender's document in Firebase
                var users = await _firebaseClient
                    .Child("users")
                    .OnceAsync<dynamic>();

                var sender = users.FirstOrDefault(u => u.Object.Email == userEmail);
                if (sender == null)
                {
                    ViewBag.ErrorMessage = "User not found.";
                    return RedirectToAction("Login", "Student");
                }

                // Get the user's Firebase key
                var userKey = sender.Key;

                // Prepare message data
                var message = new
                {
                    Content = messageContent,
                    UserType = "Student", // Adjust based on your implementation
                    Timestamp = DateTime.UtcNow.AddHours(2).ToString("yyyy-MM-dd HH:mm:ss")
                };

                // Add the message to the communication sub-collection
                await _firebaseClient
                    .Child($"users/{userKey}/communication")
                    .PostAsync(message);

                Console.WriteLine("Message successfully sent.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending message: {ex.Message}");
                throw;
            }

            return RedirectToAction("Messages", "Dashboard");
        }*/

        public async Task<IActionResult> Messages()
        {
            try
            {
                // Fetch messages using Message() method
                var messages = await Message();  // Get messages from Firebase
                return View(messages);  // Pass the message list to the view
            }
            catch (Exception ex)
            {
                // Handle the exception
                Console.WriteLine($"Error: {ex.Message}");
                return View(new List<Message>());  // Return an empty list in case of error
            }
        }
        /*
        public async Task<List<Message>> Message()
        {
            // Ensure user is logged in
            var userEmail = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(userEmail))
            {
                throw new Exception("User not logged in.");
            }

            try
            {
                // Fetch all users to find the user's document in Firebase
                var users = await _firebaseClient
                    .Child("users")
                    .OnceAsync<dynamic>();

                var user = users.FirstOrDefault(u => u.Object.Email == userEmail);
                if (user == null)
                {
                    throw new Exception("User not found.");
                }

                // Get the user's Firebase key
                var userKey = user.Key;

                // Retrieve all messages from the `communication` sub-collection
                var messages = await _firebaseClient
                    .Child($"users/{userKey}/communication")
                    .OnceAsync<dynamic>();
                Console.WriteLine("This is the user key: " + userKey);

                // Convert Firebase data to a list of Message objects
                var messageList = messages.Select(m => new Message
                {
                    Content = m.Object.Content,
                    UserType = m.Object.UserType,
                    Timestamp = DateTime.Parse(m.Object.Timestamp)
                }).ToList();

                // Sort messages by Timestamp locally
                return messageList.OrderBy(m => m.Timestamp).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving messages: {ex.Message}");
                throw;
            }
        }*/
        public async Task<List<Message>> Message()
        {
            // Ensure user is logged in
            var userEmail = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(userEmail))
            {
                throw new Exception("User not logged in.");
            }

            try
            {
                // Fetch all users to find the user's document in Firebase
                var users = await _firebaseClient
                    .Child("users")
                    .OnceAsync<dynamic>();

                var user = users.FirstOrDefault(u => u.Object.Email == userEmail);
                if (user == null)
                {
                    throw new Exception("User not found.");
                }

                // Get the user's Firebase key
                var userKey = user.Key;

                // Retrieve all messages from the `communication` sub-collection
                var messages = await _firebaseClient
                    .Child($"users/{userKey}/communication")
                    .OnceAsync<dynamic>();

                // Convert Firebase data to a list of Message objects
                var messageList = messages.Select(m => new Message
                {
                    Content = m.Object.Content,
                    UserType = m.Object.UserType,
                    Timestamp = ParseTimestamp(m.Object.Timestamp.ToString()) // Ensure it's a string
                }).ToList();

                // Sort messages by Timestamp locally
                return messageList.OrderBy(m => m.Timestamp).ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving messages: {ex.Message}");
                throw;
            }
        }

        // Method to safely parse the timestamp using ParseExact
        private DateTime ParseTimestamp(string timestamp)
        {
            // Define the exact format
            string format = "yyyy-MM-dd HH:mm:ss";

            // Try to parse using the exact format
            DateTime parsedTimestamp;
            if (DateTime.TryParseExact(timestamp, format, null, System.Globalization.DateTimeStyles.None, out parsedTimestamp))
            {
                return parsedTimestamp;
            }
            else
            {
                // Handle the case where parsing fails
                Console.WriteLine($"Invalid timestamp: {timestamp}");
                return DateTime.MinValue; // Return a default value if parsing fails
            }
        }






        /*
           [HttpPost]
   public async Task<IActionResult> SubmitFeedback(string queryId, int rating, string comments)
   {
       var firebaseClient = FirebaseService.GetFirebaseClient();
       var studentEmail = HttpContext.Session.GetString("UserEmail");

       if (string.IsNullOrEmpty(studentEmail))
       {
           return RedirectToAction("Login", "Student");
       }

       var feedback = new Feedback
       {
           QueryId = queryId,
           StudentEmail = studentEmail,
           Rating = rating,
           Comments = comments,
           SubmittedDate = DateTime.UtcNow
       };

       // Store the feedback in Firebase
       await firebaseClient
           .Child("feedback")
           .Child(queryId)
           .PostAsync(feedback);

       return RedirectToAction("QueryDetails", new { queryId });
   }
           */



        // Mock data for FAQs and Knowledge Base (replace with your database fetching logic)
        public IActionResult KnowledgeBase()
        {
            var faqList = new List<Faq>
    {
        new Faq { Question = "How can I reset my password?", Answer = "You can reset your password by clicking the 'Forgot Password' link on the login page." },
        new Faq { Question = "How do I track my query?", Answer = "Go to 'Status Tracking' in the dashboard to view your active queries and their current status." },
        new Faq { Question = "Where can I find academic resources?", Answer = "Check the 'Knowledge Base' section for various academic resources and guides." },
        new Faq { Question = "How do I submit a query?", Answer = "You can submit a query through the 'Submit Query' section in your dashboard." },
        new Faq { Question = "What are the working hours of the support team?", Answer = "The support team works from Monday to Friday, 9 AM to 5 PM." },
        new Faq { Question = "How can I contact the support team?", Answer = "You can contact support through the 'Contact Us' page on the website." },
        new Faq { Question = "Can I view the status of my previous queries?", Answer = "Yes, you can view the status of all your past queries in the 'Query History' section." },
        new Faq { Question = "How do I know if my query has been resolved?", Answer = "You will receive a notification once your query has been resolved." },
        new Faq { Question = "Is there a way to prioritize my query?", Answer = "You can mark your query as urgent while submitting it to prioritize the resolution." },
        new Faq { Question = "Can I cancel a submitted query?", Answer = "Yes, you can cancel your query from the 'My Queries' section if it's still in the pending status." }
    };

            var knowledgeBase = new List<KnowledgeBaseArticle>
    {
        new KnowledgeBaseArticle { Title = "Student Query Submission Guide", Content = "This guide will help you submit a query through the UQMS." },
        new KnowledgeBaseArticle { Title = "Using the Query Tracking System", Content = "Learn how to track the status of your queries through the system." },
        new KnowledgeBaseArticle { Title = "Best Practices for Submitting Queries", Content = "Ensure that your query contains all the relevant details for faster resolution." },
        new KnowledgeBaseArticle { Title = "Understanding Your Query Status", Content = "This article explains the different statuses that a query can have in the system." },
        new KnowledgeBaseArticle { Title = "Managing Multiple Queries", Content = "Learn how to handle and manage multiple active queries simultaneously." },
        new KnowledgeBaseArticle { Title = "Troubleshooting Login Issues", Content = "If you're having trouble logging in, this guide will walk you through common solutions." },
        new KnowledgeBaseArticle { Title = "How to Use the Query Feedback System", Content = "Learn how to provide feedback on the resolution of your query to help improve the service." },
        new KnowledgeBaseArticle { Title = "System Notifications and Alerts", Content = "This article explains the different types of notifications you will receive in the system." },
        new KnowledgeBaseArticle { Title = "UQMS Mobile App Features", Content = "Learn how to use the mobile app version of UQMS for submitting and tracking queries." },
        new KnowledgeBaseArticle { Title = "Security and Privacy in UQMS", Content = "Understand how your personal and academic data is secured in UQMS." }
    };

            ViewBag.FaqList = faqList;
            ViewBag.KnowledgeBase = knowledgeBase;

            return View();
        }

    }
}
