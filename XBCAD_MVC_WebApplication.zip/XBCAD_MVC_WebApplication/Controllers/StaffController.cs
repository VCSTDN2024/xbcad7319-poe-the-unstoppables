﻿using Firebase.Database;
using Firebase.Database.Query;
using Microsoft.AspNetCore.Mvc;
using XBCAD_MVC_WebApplication.Models;

namespace XBCAD_MVC_WebApplication.Controllers
{
    public class StaffController : Controller
    {


        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(Staff staff)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Initialize FirebaseClient
                    var firebaseClient = FirebaseService.GetFirebaseClient();

                    // Save staff details to Realtime Database under "users" collection
                    await firebaseClient
                    .Child("users") // Specify the path in the database
                    .PostAsync(new
                    {
                        FirstName = staff.FirstName,
                        LastName = staff.LastName,
                        Department = staff.Department,
                        Email = staff.Email,
                        UserType = "Staff", // Default value for staff
                        Password = staff.Password, // Ensure password is hashed in real implementations
                        CreatedAt = DateTime.UtcNow // Record creation timestamp
                    });



                    TempData["Success"] = "Staff registered successfully!";
                    return RedirectToAction("Login", "Student");
                }
                catch (Exception ex)
                {
                    // Log error and return view with error message
                    ModelState.AddModelError("", $"An error occurred: {ex.Message}");
                }
            }

            return View(staff);
        }

        [HttpGet]
        public IActionResult Dashboard()
        {
            // Get the email of the logged-in user (from the session)
            var userEmail = HttpContext.Session.GetString("UserEmail");

            // If user is not logged in (email is null), redirect to the login page
            if (string.IsNullOrEmpty(userEmail))
            {
                return RedirectToAction("Login", "Student");
            }

            // Pass the userEmail to the view if necessary
            ViewBag.UserEmail = userEmail;

            return View();
        }

        public async Task<IActionResult> DepartmentQueries()
        {
            // Initialize FirebaseClient
            var firebaseClient = FirebaseService.GetFirebaseClient();

            // Fetch all queries from Firebase
            var queries = await firebaseClient
                .Child("queries")
                .OnceAsync<dynamic>();

            // Fetch all users from Firebase
            var users = await firebaseClient
                .Child("users")
                .OnceAsync<dynamic>();

            // Find the logged-in user's email and department
            var loggedInUserEmail = HttpContext.Session.GetString("UserEmail");
            var loggedInUser = users.FirstOrDefault(u => u.Object.Email?.ToString() == loggedInUserEmail);

            if (loggedInUser == null)
            {
                return NotFound("User not found.");
            }

            var department = loggedInUser.Object.Department?.ToString();

            // Pass the department to the view
            ViewBag.Department = department;

            // Map queries to QueryViewModel and filter by department
            var queryList = queries
                .Where(q => q.Object.Department?.ToString() == department)
                .Select(q => new QueryViewModel
                {
                    QueryID = q.Key,
                    QueryType = q.Object["QueryType"]?.ToString(),
                    Title = q.Object["Title"]?.ToString(),
                    Description = q.Object["Description"]?.ToString(),
                    Status = q.Object["Status"]?.ToString(),
                    SubmissionDate = q.Object["SubmissionDate"]?.ToString(),
                    DocumentPath = q.Object["DocumentPath"]?.ToString(),
                    StudentEmail = q.Object["StudentEmail"]?.ToString()
                })
                .ToList();

            // Pass data to the view
            ViewBag.Queries = queryList;

            return View();
        }



        private async Task<List<QueryDetails>> GetAllQueries()
        {
            var queries = new List<QueryDetails>();

            // Initialize FirebaseClient
            var _firebaseClient = FirebaseService.GetFirebaseClient();

            // Fetch all queries from Firebase
            var queryData = await _firebaseClient
                .Child("queries")
                .OnceAsync<dynamic>();

            foreach (var query in queryData)
            {
                var queryDetails = new QueryDetails
                {
                    Title = query.Object.title,
                    QueryType = query.Object.queryType,
                    Department = query.Object.department,
                    SubmissionDate = DateTime.Parse(query.Object.submissionDate),
                    ResolvedDate = query.Object.resolvedDate != null ? (DateTime?)DateTime.Parse(query.Object.resolvedDate) : null
                };

                queries.Add(queryDetails);
            }

            return queries;
        }

        private async Task<List<UserDetails>> GetAllUsers()
        {
            var users = new List<UserDetails>();

            // Initialize FirebaseClient

            var _firebaseClient = FirebaseService.GetFirebaseClient();
            // Fetch all users from Firebase
            var userData = await _firebaseClient
                .Child("users")
                .OnceAsync<dynamic>();

            foreach (var user in userData)
            {
                var userDetails = new UserDetails
                {
                    Email = user.Object.email,
                    Department = user.Object.department
                };

                users.Add(userDetails);
            }

            return users;
        }



        [HttpPost]
        public async Task<IActionResult> UpdateQueryStatusResolved(string queryId)
        {
            // Initialize FirebaseClient
            var firebaseClient = FirebaseService.GetFirebaseClient();

            // Fetch the query by QueryId
            var queryToUpdate = await firebaseClient
                .Child("queries")
                .Child(queryId)
                .OnceSingleAsync<dynamic>();

            if (queryToUpdate != null)
            {
                // Create a dictionary with the updated values
                var updatedQuery = new Dictionary<string, object>
        {
            { "QueryType", queryToUpdate["QueryType"] },
            { "Title", queryToUpdate["Title"] },
            { "Description", queryToUpdate["Description"] },
            { "DocumentPath", queryToUpdate["DocumentPath"] },
            { "Department", queryToUpdate["Department"] }, // Include department
            { "Status", "Resolved" }, // Set status to "Resolved"
            { "SubmissionDate", queryToUpdate["SubmissionDate"] },
            { "StudentEmail", queryToUpdate["StudentEmail"] },
            { "ResolvedDate",DateTime.UtcNow.AddHours(2).ToString("yyyy-MM-dd HH:mm:ss") } // Add resolved date
        };

                // Update the query in Firebase
                await firebaseClient
                    .Child("queries")
                    .Child(queryId)
                    .PutAsync(updatedQuery);
            }

            // Redirect back to the same page after updating the status
            return RedirectToAction("DepartmentQueries");
        }


        [HttpPost]
        public async Task<IActionResult> UpdateQueryStatusInProgress(string queryId)
        {
            // Initialize FirebaseClient
            var firebaseClient = FirebaseService.GetFirebaseClient();

            // Fetch the query by QueryId
            var queryToUpdate = await firebaseClient
                .Child("queries")
                .Child(queryId)
                .OnceSingleAsync<dynamic>();

            if (queryToUpdate != null)
            {
                // Create a dictionary with the updated values
                var updatedQuery = new Dictionary<string, object>
        {
            { "QueryType", queryToUpdate["QueryType"] },
            { "Title", queryToUpdate["Title"] },
            { "Description", queryToUpdate["Description"] },
            { "DocumentPath", queryToUpdate["DocumentPath"] },
            { "Department", queryToUpdate["Department"] }, // Include department
            { "Status", "In Progress" }, // Set status to "Resolved"
            { "SubmissionDate", queryToUpdate["SubmissionDate"] },
            { "StudentEmail", queryToUpdate["StudentEmail"] },

        };

                // Update the query in Firebase
                await firebaseClient
                    .Child("queries")
                    .Child(queryId)
                    .PutAsync(updatedQuery);
            }

            // Redirect back to the same page after updating the status
            return RedirectToAction("DepartmentQueries");
        }


        public async Task<IActionResult> Report()
        {
            // Initialize FirebaseClient
            var firebaseClient = FirebaseService.GetFirebaseClient();

            // Fetch all queries from Firebase
            var queries = await firebaseClient
                .Child("queries")
                .OnceAsync<dynamic>();

            // Map queries to QueryViewModel for resolved queries
            var queryList = queries
                .Where(q => q.Object.Status?.ToString() == "Resolved") // Filter only resolved queries
                .Select(q =>
                {
                    // Parse the necessary fields from the query object
                    var submissionDate = q.Object["SubmissionDate"]?.ToString();
                    var resolvedDate = q.Object["ResolvedDate"]?.ToString();

                    // Calculate the time difference between SubmissionDate and ResolvedDate (if both are present)
                    DateTime? submissionDateTime = null;
                    DateTime? resolvedDateTime = null;

                    if (DateTime.TryParse(submissionDate, out DateTime subDate))
                    {
                        submissionDateTime = subDate;
                    }

                    if (DateTime.TryParse(resolvedDate, out DateTime resDate))
                    {
                        resolvedDateTime = resDate;
                    }

                    TimeSpan? timeDifference = null;

                    if (submissionDateTime.HasValue && resolvedDateTime.HasValue)
                    {
                        timeDifference = resolvedDateTime.Value - submissionDateTime.Value;
                    }

                    // Return a new QueryViewModel with the filtered data
                    return new ReportQueryViewModel
                    {
                        QueryID = q.Key,
                        Title = q.Object["Title"]?.ToString(),
                        QueryType = q.Object["QueryType"]?.ToString(),
                        Department = q.Object["Department"]?.ToString(),
                        SubmissionDate = submissionDate,
                        ResolvedDate = resolvedDate,
                        TimeDifference = timeDifference?.ToString(@"d\.hh\:mm\:ss") // Format the time difference as days.hours:minutes:seconds
                    };
                })
                .ToList();

            // Pass the query list to the view
            ViewBag.Queries = queryList;

            return View();
        }


        /*
        public async Task<IActionResult> Report()
        {
            var queries = await GetAllQueries();

            // Create the dashboard model to hold our data
            var model = new DashboardViewModel();

            // Group by department and count queries per department
            model.DepartmentQueryCounts = queries
                .GroupBy(q => q.Department)
                .ToDictionary(g => g.Key, g => g.Count());

            // Group by query type and count queries per type
            model.QueryTypeCounts = queries
                .GroupBy(q => q.QueryType)
                .ToDictionary(g => g.Key, g => g.Count());

            // Calculate average response times per department
            model.AverageResponseTimes = queries
                .Where(q => q.ResolvedDate.HasValue)
                .GroupBy(q => q.Department)
                .ToDictionary(
                    g => g.Key,
                    g => TimeSpan.FromMilliseconds(g.Average(q => (q.ResolvedDate.Value - q.SubmissionDate).TotalMilliseconds))
                );

            // Calculate the resolution rate
            model.ResolutionRate = (double)queries.Count(q => q.ResolvedDate.HasValue) / queries.Count() * 100;

            // Include all queries in the model
            model.Queries = queries;

            return View(model);
        }
        */



        public IActionResult Login()
        {
            return View();
        }


        public IActionResult Communication()
        {
            return View();
        }


    }
}