﻿using Firebase.Database;
using Firebase.Database.Query;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using XBCAD_MVC_WebApplication.Models;

namespace XBCAD_MVC_WebApplication.Controllers
{
    public class AccountController : Controller
    {
        private readonly FirebaseClient _firebaseClient;

        public AccountController()
        {
            _firebaseClient = FirebaseService.GetFirebaseClient();
        }

        [HttpGet]
        public IActionResult StudentLogin()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> StudentLogin(LoginViewModel login)
        {
            if (!ModelState.IsValid)
            {
                return View(login);
            }

            // Query the "Users" collection for the provided email
            var users = await _firebaseClient
                .Child("Users")
                .OnceAsync<dynamic>();

            var matchingUser = users
                .Where(u => string.Equals(u.Object.Email, login.Email, StringComparison.OrdinalIgnoreCase))
                .FirstOrDefault();

            if (matchingUser == null)
            {
                ViewBag.ErrorMessage = "Email does not exist.";
                return View(login);
            }

            // Validate the password
            if (matchingUser.Object.Password != login.Password)
            {
                ViewBag.ErrorMessage = "Password is incorrect.";
                return View(login);
            }

            // Check if the user is a student
            if (matchingUser.Object.UserType?.ToString() != "Student")
            {
                ViewBag.ErrorMessage = "This login is for students. Please use the lecturer login.";
                return View(login);
            }

            // Login successful, redirect to Index
            return RedirectToAction("Index", "Home");
        }
    }
}
