﻿using Firebase.Database;
using Firebase.Database.Query;
using Microsoft.AspNetCore.Mvc;
using XBCAD_MVC_WebApplication;
using XBCAD_MVC_WebApplication.Models;

public class PersonController : Controller
{
    private readonly FirebaseClient _firebaseClient;

    public PersonController()
    {
        // Retrieve FirebaseClient from FirebaseService
        _firebaseClient = FirebaseService.GetFirebaseClient();
    }

    [HttpGet]
    public IActionResult AddPerson()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> AddPerson(Person person)
    {
        if (ModelState.IsValid)
        {
            await _firebaseClient
                .Child("Persons")
                .PostAsync(person);

            TempData["Success"] = "Person added successfully!";
            return RedirectToAction("AddPerson");
        }
        return View(person);
    }
}
