﻿using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Mvc;
using XBCAD_MVC_WebApplication.Models;
using Google.Cloud.Firestore;
using System.Threading.Tasks;
using Firebase.Database.Query;
using Firebase.Database;

namespace XBCAD_MVC_WebApplication.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student/Register

        
        public IActionResult Register()
        {
            return View();
        }

        // POST: Student/Register
        [HttpPost]
        public async Task<IActionResult> Register(Student student)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Initialize FirebaseClient
                    var firebaseClient = FirebaseService.GetFirebaseClient();

                    // Save user details to Realtime Database under "users" collection
                    await firebaseClient
                        .Child("users")
                        .PostAsync(new
                        {
                            FirstName = student.FirstName,
                            LastName = student.LastName,
                            StudentId = student.StudentId,
                            Department = student.Department,
                            Course = student.Course,
                            Email = student.Email,
                            UserType = student.UserType, // Default "Student"
                            Password = student.Password, // Default "Student"
                            CreatedAt = DateTime.UtcNow // Record creation timestamp
                        });

                    TempData["Success"] = "Student registered successfully!";
                    return RedirectToAction("Login");
                }
                catch (Exception ex)
                {
                    // Log error and return view with error message
                    ModelState.AddModelError("", $"An error occurred: {ex.Message}");
                }
            }

            return View(student);
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel login)
        {
            if (!ModelState.IsValid)
            {
                return View(login);
            }

            // Initialize FirebaseClient
            var firebaseClient = FirebaseService.GetFirebaseClient();

            // Query the "users" collection for the provided email
            var users = await firebaseClient
                .Child("users")
                .OnceAsync<dynamic>();

            var matchingUser = users
                .Where(u =>
                {
                    var userData = u.Object as Newtonsoft.Json.Linq.JObject;
                    if (userData != null)
                    {
                        var userEmail = userData["Email"]?.ToString();
                        return string.Equals(userEmail, login.Email, StringComparison.OrdinalIgnoreCase);
                    }
                    return false;
                })
                .FirstOrDefault();

            // Check if email exists
            if (matchingUser == null)
            {
                ViewBag.ErrorMessage = "Email does not exist.";
                return View(login);
            }

            // Validate the password
            var userObject = matchingUser.Object as Newtonsoft.Json.Linq.JObject;
            if (userObject != null && userObject["Password"]?.ToString() != login.Password)
            {
                ViewBag.ErrorMessage = "Password is incorrect.";
                return View(login);
            }

            // Retrieve UserType
            var userType = userObject?["UserType"]?.ToString();

            // Redirect based on UserType
            if (string.Equals(userType, "Student", StringComparison.OrdinalIgnoreCase))
            {
                // Store the user's email in session (if required)
                HttpContext.Session.SetString("UserEmail", login.Email);

                // Redirect to student dashboard
                return RedirectToAction("Dashboard");
            }
            else if (string.Equals(userType, "Staff", StringComparison.OrdinalIgnoreCase))
            {
                // Store the user's email in session (if required)
                HttpContext.Session.SetString("UserEmail", login.Email);

                // Redirect to staff dashboard
                return RedirectToAction("Dashboard", "Staff");
            }

            // If UserType is not recognized
            ViewBag.ErrorMessage = "User type is not recognized.";
            return View(login);
        }


        /* STUDENT LOGIN ONLY - OLD
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel login)
        {
            if (!ModelState.IsValid)
            {
                return View(login);
            }

            // Initialize FirebaseClient
            var firebaseClient = FirebaseService.GetFirebaseClient();

            // Query the "Users" collection for the provided email
            var users = await firebaseClient
                .Child("users")
                .OnceAsync<dynamic>();

            var matchingUser = users
                .Where(u =>
                {
                    var userData = u.Object as Newtonsoft.Json.Linq.JObject;
                    if (userData != null)
                    {
                        var userEmail = userData["Email"]?.ToString();
                        return string.Equals(userEmail, login.Email, StringComparison.OrdinalIgnoreCase);
                    }
                    return false;
                })
                .FirstOrDefault();

            if (matchingUser == null)
            {
                ViewBag.ErrorMessage = "Email does not exist.";
                return View(login);
            }

            // Validate the password
            var userObject = matchingUser.Object as Newtonsoft.Json.Linq.JObject;
            if (userObject != null && userObject["Password"]?.ToString() != login.Password)
            {
                ViewBag.ErrorMessage = "Password is incorrect.";
                return View(login);
            }

            // Check if the user is a student
            if (userObject != null && userObject["UserType"]?.ToString() != "Student")
            {
                ViewBag.ErrorMessage = "This login is for students. Please use the lecturer login.";
                return View(login);
            }

            // Store the user's email in session
            HttpContext.Session.SetString("UserEmail", login.Email);

            // Login successful, redirect to Dashboard
            return RedirectToAction("Dashboard");
        }
        */
        [HttpGet]
        public IActionResult Dashboard()
        {
            // Get the email of the logged-in user (from the session)
            var userEmail = HttpContext.Session.GetString("UserEmail");

            // If user is not logged in (email is null), redirect to the login page
            if (string.IsNullOrEmpty(userEmail))
            {
                return RedirectToAction("Login", "Student");
            }

            // Pass the userEmail to the view if necessary
            ViewBag.UserEmail = userEmail;

            return View();
        }



    }
}
