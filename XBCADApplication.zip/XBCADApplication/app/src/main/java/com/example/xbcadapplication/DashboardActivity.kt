package com.example.xbcadapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dashboard)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Retrieve the email passed from Login activity
        val userEmail = intent.getStringExtra("UserEmail")

        // Now you can use userEmail in this activity
        if (userEmail != null) {
            // For example, display the email or use it in queries
            Toast.makeText(this, "Welcome, $userEmail!", Toast.LENGTH_SHORT).show()
        }

        val buttonFAQ: Button = findViewById(R.id.buttonFAQ)

        // Handle Sign Up Button Click
        buttonFAQ.setOnClickListener {
            // Navigate to Sign Up activity
            startActivity(Intent(this, FaqActivity::class.java))
        }

        val buttonQuery: Button = findViewById(R.id.buttonQuery)

        // Handle Sign Up Button Click
        buttonQuery.setOnClickListener {
            // Navigate to Sign Up activity
            //startActivity(Intent(this, CreateQueryActivity::class.java))

            // Navigate with email:
            // Navigate to CreateQueryActivity with email
            val intent = Intent(this, CreateQueryActivity::class.java)
            intent.putExtra("UserEmail", userEmail) // Pass the correct email
            startActivity(intent)
            finish()
            Log.d("DashboardActivity", "UserEmail: $userEmail")

        }

        val buttonTracking: Button = findViewById(R.id.buttonTracking)

        // Handle Sign Up Button Click
        buttonTracking.setOnClickListener {
            // Navigate to Sign Up activity
            //startActivity(Intent(this, StatusTrackingActivity::class.java))

            // Navigate with email:
            val intent = Intent(this, StatusTrackingActivity::class.java)
            intent.putExtra("UserEmail", userEmail) // Pass the correct email
            startActivity(intent)
            finish()
        }


    }
}