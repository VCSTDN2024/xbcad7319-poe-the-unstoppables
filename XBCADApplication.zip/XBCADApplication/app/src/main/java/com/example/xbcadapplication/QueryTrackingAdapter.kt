package com.example.xbcadapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class QueryTrackingAdapter(
    private val context: Context,
    private val list: ArrayList<QueryTrackingModel>
) : RecyclerView.Adapter<QueryTrackingAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tv_type: TextView = itemView.findViewById(R.id.tv_type)
        private val tv_title: TextView = itemView.findViewById(R.id.tv_title)
        private val tv_description: TextView = itemView.findViewById(R.id.tv_description)
        private val tv_status: TextView = itemView.findViewById(R.id.tv_status)

        fun bind(position: Int) {
            tv_type.text = list[position].type
            tv_title.text = list[position].title
            tv_description.text = list[position].description
            tv_status.text = list[position].status
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.query_tracking, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int {
        return list.size
    }
}
