package com.example.xbcadapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FaqActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_faq)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonDashboard: Button = findViewById(R.id.buttonDashboard)

        // Handle Sign Up Button Click
        buttonDashboard.setOnClickListener {
            // Navigate to Sign Up activity
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        val reyclerView = findViewById<RecyclerView>(R.id.recyclerView);

        val  data = arrayListOf<FaqModel>();

        data.add(
            FaqModel(
                "How can I reset my password?",
                "You can reset your password by clicking the 'Forgot Password' link on the login page."
            )
        )
        data.add(
            FaqModel(
                "How do I track my query?",
                "Go to 'Status Tracking' in the dashboard to view your active queries and their current status."
            )
        )
        data.add(
            FaqModel(
                "Where can I find academic resources?",
                "Check the 'Knowledge Base' section for various academic resources and guides."
            )
        )
        data.add(
            FaqModel(
                "How do I submit a query?",
                "You can submit a query through the 'Submit Query' section in your dashboard."
            )
        )
        data.add(
            FaqModel(
                "What are the working hours of the support team?",
                "The support team works from Monday to Friday, 9 AM to 5 PM."
            )
        )
        data.add(
            FaqModel(
                "How can I contact the support team?",
                "You can contact support through the 'Contact Us' page on the website."
            )
        )
        data.add(
            FaqModel(
                "Can I view the status of my previous queries?",
                "Yes, you can view the status of all your past queries in the 'Query History' section."
            )
        )
        data.add(
            FaqModel(
                "How do I know if my query has been resolved?",
                "You will receive a notification once your query has been resolved."
            )
        )
        data.add(
            FaqModel(
                "Is there a way to prioritize my query?",
                "You can mark your query as urgent while submitting it to prioritize the resolution."
            )
        )
        data.add(
            FaqModel(
                "Can I cancel a submitted query?",
                "Yes, you can cancel your query from the 'My Queries' section if it's still in the pending status."
            )
        )


        val adapter = CustomAdapter(this, data);
        reyclerView.layoutManager = LinearLayoutManager(this)
        reyclerView.adapter = adapter
    }
}