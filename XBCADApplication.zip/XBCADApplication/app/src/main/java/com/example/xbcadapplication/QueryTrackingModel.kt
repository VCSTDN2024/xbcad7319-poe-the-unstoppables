package com.example.xbcadapplication

data class QueryTrackingModel(val type: String, val title: String, val description: String, val status: String, )
