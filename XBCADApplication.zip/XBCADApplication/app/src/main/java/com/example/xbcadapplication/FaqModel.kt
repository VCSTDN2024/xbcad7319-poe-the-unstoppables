package com.example.xbcadapplication

public data class FaqModel(val title: String, val name: String)
