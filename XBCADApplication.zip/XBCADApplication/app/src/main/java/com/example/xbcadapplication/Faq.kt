package com.example.xbcadapplication

data class Faq(val question: String, val answer: String)