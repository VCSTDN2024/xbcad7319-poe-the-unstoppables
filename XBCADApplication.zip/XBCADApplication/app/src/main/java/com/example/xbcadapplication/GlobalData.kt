package com.example.xbcadapplication

object GlobalData {
    var userEmail: String? = null
}