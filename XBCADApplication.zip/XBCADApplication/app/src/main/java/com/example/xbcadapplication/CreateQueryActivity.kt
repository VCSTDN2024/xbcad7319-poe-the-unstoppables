package com.example.xbcadapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class CreateQueryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_create_query)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //val studentEmail = intent.getStringExtra("UserEmail")
        val studentEmail = GlobalData.userEmail
        Log.d("CreateQueryActivity", "Received UserEmail: $studentEmail")
        Toast.makeText(this, "Make queries here, $studentEmail!", Toast.LENGTH_SHORT).show()

        val buttonDashboard: Button = findViewById(R.id.buttonDashboard)

        // Handle Sign Up Button Click
        buttonDashboard.setOnClickListener {
            // Navigate to Sign Up activity
            startActivity(Intent(this, DashboardActivity::class.java))
        }
        val titleInput: EditText = findViewById(R.id.titleInput)
        val descriptionInput: EditText = findViewById(R.id.descriptionInput)
        val categoryDropdown: Spinner = findViewById(R.id.categoryDropdown)
        val submitButton: Button = findViewById(R.id.loginButton3)

        submitButton.setOnClickListener {
            val title = titleInput.text.toString().trim()
            val description = descriptionInput.text.toString().trim()
            val queryType = categoryDropdown.selectedItem.toString()

            // Validate inputs
            if (title.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }




            // Fetch user's department from the database
            val database = FirebaseDatabase.getInstance()
            val usersRef = database.getReference("users")

            usersRef.orderByChild("Email").equalTo(studentEmail)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            // Fetch the user's department
                            val userSnapshot = snapshot.children.first()
                            val department =
                                userSnapshot.child("Department").value as? String ?: "Unknown"

                            // Generate unique Query ID
                            val queryId = UUID.randomUUID().toString()

                            // Inside your code
                            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                            val currentDate = dateFormat.format(Date())

                            // Prepare query data
                            val queryData = mapOf(
                                "QueryID" to queryId,
                                "StudentEmail" to studentEmail,
                                "DocumentPath" to "null",
                                "Department" to department, // Add department here
                                "QueryType" to queryType,
                                "Title" to title,
                                "Description" to description,
                                "SubmissionDate" to currentDate, // Timestamp
                                "Status" to "Pending",
                            )

                            // Save query to Firebase
                            val queryRef = database.getReference("queries").child(queryId)
                            queryRef.setValue(queryData)
                                .addOnSuccessListener {
                                    Toast.makeText(
                                        this@CreateQueryActivity,
                                        "Query submitted successfully!",
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    titleInput.setText("");
                                    descriptionInput.setText("");

                                }
                                .addOnFailureListener { exception ->
                                    Toast.makeText(
                                        this@CreateQueryActivity,
                                        "Failed to submit query: ${exception.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                        } else {
                            Toast.makeText(
                                this@CreateQueryActivity,
                                "User not found.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(
                            this@CreateQueryActivity,
                            "Error: ${error.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
        }

    }
}