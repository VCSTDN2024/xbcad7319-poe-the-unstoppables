package com.example.xbcadapplication

import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class KnowledgeBaseAdapter(private val kbList: List<KnowledgeBaseArticle>) : RecyclerView.Adapter<KnowledgeBaseAdapter.KBViewHolder>(), Parcelable {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KBViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_kb, parent, false)
        return KBViewHolder(view)
    }

    override fun onBindViewHolder(holder: KBViewHolder, position: Int) {
        holder.bind(kbList[position])
    }

    override fun getItemCount(): Int {
        return kbList.size
    }

    class KBViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(article: KnowledgeBaseArticle) {
            itemView.findViewById<TextView>(R.id.textTitle).text = article.title
            itemView.findViewById<TextView>(R.id.textContent).text = article.content
        }
    }

    // Parcelable implementation
    constructor(parcel: Parcel) : this(
        mutableListOf<KnowledgeBaseArticle>().apply {
            parcel.readList(this, KnowledgeBaseArticle::class.java.classLoader)
        }
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeList(kbList)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<KnowledgeBaseAdapter> {
        override fun createFromParcel(parcel: Parcel): KnowledgeBaseAdapter {
            return KnowledgeBaseAdapter(parcel)
        }

        override fun newArray(size: Int): Array<KnowledgeBaseAdapter?> {
            return arrayOfNulls(size)
        }
    }
}
