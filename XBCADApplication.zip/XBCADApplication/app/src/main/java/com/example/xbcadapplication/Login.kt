package com.example.xbcadapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class Login : AppCompatActivity() {

    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: Button
    private lateinit var errorMessage: TextView

    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val buttonBack: Button = findViewById(R.id.buttonBack)
        // Handle Sign Up Button Click
        buttonBack.setOnClickListener {
            // Navigate to Sign Up activity
            startActivity(Intent(this, MainActivity::class.java))
        }


        // Initialize views
        emailInput = findViewById(R.id.emailInput)
        passwordInput = findViewById(R.id.passwordInput)
        loginButton = findViewById(R.id.loginButton)
        errorMessage = findViewById(R.id.textViewErrorMessage)

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("users")

        loginButton.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                errorMessage.text = "Please fill in all fields"
                return@setOnClickListener
            }

            validateUser(email, password)
        }
    }

    private fun validateUser(email: String, password: String) {
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var userFound = false
                for (userSnapshot in snapshot.children) {
                    val userEmail = userSnapshot.child("Email").getValue(String::class.java)
                    val userPassword = userSnapshot.child("Password").getValue(String::class.java)
                    val userType = userSnapshot.child("UserType").getValue(String::class.java)

                    if (userEmail.equals(email, ignoreCase = true)) {
                        userFound = true
                        if (userPassword == password) {
                            // Navigate based on UserType
                            when (userType?.lowercase()) {
                                "student" -> {
                                    navigateToDashboard()
                                }
                                "staff" -> {
                                  //  navigateToStaffDashboard()
                                }
                                else -> {
                                    errorMessage.text = "User type is not recognized."
                                }
                            }
                        } else {
                            errorMessage.text = "Password is incorrect."
                        }
                        break
                    }
                }

                if (!userFound) {
                    errorMessage.text = "Email does not exist."
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@Login, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun navigateToDashboard() {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra("UserEmail", emailInput.text.toString())
        GlobalData.userEmail = emailInput.text.toString()

        startActivity(intent)
        finish()
    }
/*
    private fun navigateToStaffDashboard() {
        val intent = Intent(this, StaffDashboardActivity::class.java)
        intent.putExtra("UserEmail", emailInput.text.toString())
        startActivity(intent)
        finish()
    }*/
}
