package com.example.xbcadapplication

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.database.FirebaseDatabase
import java.util.*

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonBack: Button = findViewById(R.id.buttonBack)
        val buttonRegister: Button = findViewById(R.id.buttonRegister)

        // Inputs
        val firstNameInput: EditText = findViewById(R.id.inputFirstName)
        val lastNameInput: EditText = findViewById(R.id.inputLastName)
        val studentIdInput: EditText = findViewById(R.id.inputStudentID)
        val emailInput: EditText = findViewById(R.id.emailInput)
        val courseInput: EditText = findViewById(R.id.courseInput)
        val passwordInput: EditText = findViewById(R.id.passwordInput)
        val departmentDropdown: Spinner = findViewById(R.id.departmentDropdown)

        // Handle Back Button Click
        buttonBack.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        // Handle Register Button Click
        buttonRegister.setOnClickListener {
            val firstName = firstNameInput.text.toString().trim()
            val lastName = lastNameInput.text.toString().trim()
            val studentId = studentIdInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val course = courseInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()
            val department = departmentDropdown.selectedItem.toString()

            // Validate inputs
            if (firstName.isEmpty() || lastName.isEmpty() || studentId.isEmpty() ||
                email.isEmpty() || course.isEmpty() || password.isEmpty()
            ) {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Save user data to Firebase
            val database = FirebaseDatabase.getInstance()
            val usersRef = database.getReference("users")

            // Generate a unique ID for the user
            val userId = UUID.randomUUID().toString()

            val userData = mapOf(
                "UserID" to userId,
                "FirstName" to firstName,
                "LastName" to lastName,
                "StudentID" to studentId,
                "Email" to email,
                "Course" to course,
                "Department" to department,
                "Password" to password,
                "UserType" to "Student",
                "CreatedAt" to System.currentTimeMillis() // Timestamp
            )

            usersRef.child(userId).setValue(userData)
                .addOnSuccessListener {
                    Toast.makeText(
                        this@RegisterActivity,
                        "Registration successful!",
                        Toast.LENGTH_SHORT
                    ).show()
                    // Navigate back to the main activity
                    startActivity(Intent(this, MainActivity::class.java))
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(
                        this@RegisterActivity,
                        "Failed to register: ${exception.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }
    }
}
