package com.example.xbcadapplication

import android.os.Parcel
import android.os.Parcelable

data class KnowledgeBaseArticle(
    val title: String,
    val content: String
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(title)
        parcel.writeString(content)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<KnowledgeBaseArticle> {
        override fun createFromParcel(parcel: Parcel): KnowledgeBaseArticle {
            return KnowledgeBaseArticle(parcel)
        }

        override fun newArray(size: Int): Array<KnowledgeBaseArticle?> {
            return arrayOfNulls(size)
        }
    }
}
