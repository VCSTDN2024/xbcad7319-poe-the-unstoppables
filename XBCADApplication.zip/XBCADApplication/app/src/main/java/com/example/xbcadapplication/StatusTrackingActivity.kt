package com.example.xbcadapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class StatusTrackingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_status_tracking)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonDashboard: Button = findViewById(R.id.buttonDashboard)

        // Handle Sign Up Button Click
        buttonDashboard.setOnClickListener {
            // Navigate to Sign Up activity
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Firebase reference
        val database = FirebaseDatabase.getInstance()
        val queriesRef = database.getReference("queries")

        // ArrayList to hold the fetched data
        val data = arrayListOf<QueryTrackingModel>()

        // Retrieve the email passed from Dashboard activity
        //val studentEmail = intent.getStringExtra("UserEmail")
        val studentEmail = GlobalData.userEmail
        queriesRef.orderByChild("StudentEmail").equalTo(studentEmail)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (querySnapshot in snapshot.children) {
                            // Extract data for each query
                            val queryType = querySnapshot.child("QueryType").value as? String ?: "Unknown"
                            val title = querySnapshot.child("Title").value as? String ?: "No Title"
                            val description = querySnapshot.child("Description").value as? String ?: "No Description"
                            val status = querySnapshot.child("Status").value as? String ?: "Unknown"

                            // Add the query to the list
                            data.add(QueryTrackingModel(queryType, title, description, status))
                        }
                    }

                    // Set up the adapter with fetched data
                    val adapter = QueryTrackingAdapter(this@StatusTrackingActivity, data)
                    recyclerView.adapter = adapter
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle errors
                }
            })


    }
}